#! /bin/bash
gcc hw2b.c -fopenmp -o hw2b
./hw2b 10 4
rm hw2b
