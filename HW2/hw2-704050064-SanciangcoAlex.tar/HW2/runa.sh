#! /bin/bash
gcc hw2a.c -fopenmp -o hw2a
./hw2a 10 4
rm hw2a
