export MPI_ROOT=/usr/local/cs133/openmpi-install
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$MPI_ROOT/lib
export PATH=$PATH:$MPI_ROOT/bin
